package com.cg.media.dao;

import java.util.List;

import com.cg.media.dto.Artist_Master;
import com.cg.media.dto.Composer_Master;
import com.cg.media.dto.Song_Master;

public interface MediaDao 
{

	public int addSongs(Song_Master sm);
	public List<Song_Master> retrieveArtist(String artistName);
	public List<Artist_Master> retrieveAllArtist();
	public List<Composer_Master> retrieveAllComposer();
	public List<Song_Master> retrieveComposer(String composerName);
	
	public String getName(String artistName);
}
