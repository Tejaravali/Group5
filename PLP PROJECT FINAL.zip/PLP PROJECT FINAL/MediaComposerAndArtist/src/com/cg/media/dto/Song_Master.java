package com.cg.media.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="song_master")
public class Song_Master 
{
	@Id
	@Column(name="song_id")
	private int songId;
	
	@Column(name="song_name")
	private String songName;
	
	@Column(name="artist_name")
	private String artistName;
	
	@Column(name="composer_name")
	private String composerName;
	
	@Column(name="song_duration")
	private String songDuration;
	
	@Column(name="release_date")
	private String releaseDate;
	
	
	public int getSongId() 
	{
		return songId;
	}
	public void setSongId(int songId)
	{
		this.songId = songId;
	}
	public String getSongName()
	{
		return songName;
	}
	public void setSongName(String songName) 
	{
		this.songName = songName;
	}
	public String getArtistName()
	{
		return artistName;
	}
	public void setArtistName(String artistName) 
	{
		this.artistName = artistName;
	}
	public String getComposerName() 
	{
		return composerName;
	}
	public void setComposerName(String composerName) 
	{
		this.composerName = composerName;	
	}
	public String getSongDuration() 
	{
		return songDuration;
	}
	public void setSongDuration(String songDuration) 
	{
		this.songDuration = songDuration;
	}
	public String getReleaseDate() 
	{
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) 
	{
		this.releaseDate = releaseDate;
	}
	
	
	

}
