package com.cg.media.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import com.sun.istack.internal.NotNull;

@Entity
@Table(name="composer_master")
public class Composer_Master 
{
	@Id
	@Column(name="composer_id")
	private int composerId;
	
	@NotNull
	@Size(min=3, max=20)
	@Column(name="composer_name")
	private String composerName;
	
	@NotNull
	@Column(name="composer_gender")
	private String composerGender;
	
	@NotNull
	@Column(name="composer_birth_date")
	private String composer_birth_date;
	
	public int getComposerId() 
	{
		return composerId;
	}
	public void setComposerId(int composerId) 
	{
		
		this.composerId = composerId;
	}
	public String getComposerName() 
	{
		return composerName;
	}
	public void setComposerName(String composerName) 
	{
		this.composerName = composerName;
	}
	public String getComposerGender() 
	{
		return composerGender;
	}
	public void setComposerGender(String composerGender) 
	{
		this.composerGender = composerGender;
	}
	public String getComposer_birth_date() 
	{
		return composer_birth_date;
	}
	public void setComposer_birth_date(String composer_birth_date) 
	{
		this.composer_birth_date = composer_birth_date;
	}
	

	
}
