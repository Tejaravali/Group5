package com.cg.media.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="song_master")
public class Song_Master 
{
	@Id
	@Column(name="song_id")
	@NotNull(message="Song Id should not be empty")
	@Min(1)
	@Max(99)
	private int songId;
	


	@Column(name="song_name")
	@NotEmpty(message="Name should not be empty")
	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Song name must contain only alphabets")
	private String songName;
	


	@Column(name="artist_name")
	@NotEmpty(message="Artist Name should not be Empty")
	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Artist name must contain only alphabets")
	private String artistName;
	


	@Column(name="composer_name")
	@NotEmpty(message="composer Name should not be Empty")
	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Composer must contain only alphabets")
	private String composerName;
	
	
	@Column(name="song_duration")
	@NotEmpty(message="Song duration should not be empty")
	@Pattern(regexp = "[1-9]:[0-5][0-9]", message = "Song Duration should be like= 3:57")
	private String songDuration;
	
	@Column(name="release_date")
	@NotEmpty(message="Release date not given")
	@Pattern(regexp = "[1-2][0-9][0-9][0-7]", message = "Year should be less than current year")
	private String releaseDate;
	
	
	public int getSongId() 
	{
		return songId;
	}
	public void setSongId(int songId)
	{
		this.songId = songId;
	}
	public String getSongName()
	{
		return songName;
	}
	public void setSongName(String songName) 
	{
		this.songName = songName;
	}
	public String getArtistName()
	{
		return artistName;
	}
	public void setArtistName(String artistName) 
	{
		this.artistName = artistName;
	}
	public String getComposerName() 
	{
		return composerName;
	}
	public void setComposerName(String composerName) 
	{
		this.composerName = composerName;	
	}
	public String getSongDuration() 
	{
		return songDuration;
	}
	public void setSongDuration(String songDuration) 
	{
		this.songDuration = songDuration;
	}
	public String getReleaseDate() 
	{
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) 
	{
		this.releaseDate = releaseDate;
	}
	
	
	

}
