package com.cg.media.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import com.sun.istack.internal.NotNull;

@Entity
@Table(name="artist_master")
public class Artist_Master 
{
		@Id
		@Column(name="artist_id")
		private int artistId;
		
		@NotNull
		@Size(min=3, max=20)
		@Column(name="artist_name")
		private String artistName;
		
		@NotNull
		@Size(min=3, max=20)
		@Column(name="artist_gender")
		private String artistGender;
		
		@NotNull
		@Column(name="artist_birth_date")
		private String artistBirthDate;
		
		public int getArtistId() 
		{
			return artistId;
		}
		public void setArtistId(int artistId) 
		{
			this.artistId = artistId;
		}
		public String getArtistName() 
		{
			return artistName;
		}
		public void setArtistName(String artistName) 
		{
			this.artistName = artistName;
		}
		public String getArtistGender()
		{
			return artistGender;
		}
		public void setArtistGender(String artistGender)
		{
			this.artistGender = artistGender;
		}
		public String getArtistBirthDate() 
		{
			return artistBirthDate;
		}
		public void setArtistBirthDate(String artistBirthDate) 
		{
			this.artistBirthDate = artistBirthDate;
		}
		
		
		

}
