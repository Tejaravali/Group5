package com.cg.ui;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.entity.Employee;

public class JPAClient {

	public static void main(String[] args) 
	{
		Employee employee=new Employee();
		employee.setEmpName("Ravali");
		employee.setEmpSalary(45466);
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJPA");
		EntityManager em=emf.createEntityManager();
		EntityTransaction tsx=em.getTransaction();
		
		Query query=em.createQuery("from Employee");
		List<Employee> allRecords=query.getResultList();
		
		Query query1=em.createQuery("select max(empSalary) from Employee");
		
		for(Employee e:allRecords)
		{
			System.out.println(e);
		}
		
		float maxSal=(float)query1.getSingleResult();
		System.out.println("max salary is"+maxSal);
	/*	tsx.begin();
		Employee emp=(Employee)em.find(Employee.class, 10);
		System.out.println(emp);
		emp.setEmpName("Lakshmi");
		em.merge(emp);
		System.out.println("record is updated");
		//em.remove(employee);
		//System.out.println("object is deleted");
		//em.persist(employee);
		//System.out.println("Object is saved in DB");
		
		tsx.commit(); */
		emf.close();
	}

}
