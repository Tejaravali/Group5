package com.cg.ui;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.capgemini.utility.SessionFactoryUtility;
import com.cg.entity.Car;
import com.cg.entity.User;


public class TestManyToMany {

	public static void main(String[] args) {
		
		
		SessionFactory sf=SessionFactoryUtility.createSessionFactory();
		
		Session mySession=sf.openSession();
		Transaction txn=mySession.beginTransaction();
		
		User user1=new User();
		user1.setUserName("Vardhani");
		
		User user2=new User();
		user2.setUserName("Tejaswi");
		
		Car car1=new Car();
		car1.setCarName("i20 Asta");
		car1.setCompanyName("Hyundai");
		
		Car car2=new Car();
		car2.setCarName("Swift");
		car2.setCompanyName("Maruti");
		
		user1.getCars().add(car1);
		user2.getCars().add(car2);
		
		car1.getUsers().add(user1);
		car2.getUsers().add(user2);
		
		mySession.save(user1);
		mySession.save(user2);
		mySession.save(car1);
		mySession.save(car2);
				
		txn.commit();
		
		SessionFactoryUtility.releaseSessionFactory();
	}

}
