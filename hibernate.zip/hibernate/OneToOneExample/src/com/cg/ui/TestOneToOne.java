package com.cg.ui;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.capgemini.utility.SessionFactoryUtility;
import com.cg.entity.Address;
import com.cg.entity.Student;

public class TestOneToOne {

	public static void main(String[] args) {
		
		Student student=new Student();
		student.setName("abcd");
		
		Address address=new Address();
		
		address.setCity("Bhimavaram");
		address.setState("AP");
		address.setCountry("India");
		
		student.setAddress(address);
		
		SessionFactory sf=SessionFactoryUtility.createSessionFactory();
		
		Session mySession=sf.openSession();
		Transaction txn=mySession.beginTransaction();
		
		//mySession.save(student);
	//	mySession.save(address);
		
		Address add=(Address) mySession.get(Address.class, 0);
		System.out.println(add);
		
	//	mySession.delete(stu);
		txn.commit();
		
		SessionFactoryUtility.releaseSessionFactory();
	}

}
