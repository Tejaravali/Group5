package com.cg.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity

public class Student 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int rollNo;
	private String name;
	@OneToOne(cascade=CascadeType.ALL)
	private Address address;
	
	public int getRollNo() {
		return rollNo;
	}
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", address="
				+ address + "]";
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}
	
}
