package com.cg.ui;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.capgemini.utility.SessionFactoryUtility;
import com.cg.entity.Country;
import com.cg.entity.State;


public class TestOneToMany {

	public static void main(String[] args) {
		
		
		SessionFactory sf=SessionFactoryUtility.createSessionFactory();
		
		Session mySession=sf.openSession();
		Transaction txn=mySession.beginTransaction();
		Country country=new Country();
		country.setCountryName("India");
		State s1=new State();
		State s2=new State();
		State s3=new State();
		
		s1.setStateName("AP");
		s1.setStatePopulation(10000000);
		s1.setCountry(country);
		
		s2.setStateName("Telangana");
		s2.setStatePopulation(5000000);
		s2.setCountry(country);
		
		s3.setStateName("TN");
		s3.setStatePopulation(5646455);
		s3.setCountry(country);
		
		country.getStates().add(s1);
		country.getStates().add(s2);
		country.getStates().add(s3);
		mySession.save(country);
		
		mySession.save(s1);
		mySession.save(s2);
		mySession.save(s3);
		
		System.out.println("Data is saved...");
		txn.commit();
		
		SessionFactoryUtility.releaseSessionFactory();
	}

}
