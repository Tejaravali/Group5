package com.cg.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class State 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int stateId;
	private String stateName;
	private long statePopulation;
	
	@ManyToOne(cascade=CascadeType.ALL)
	Country country;
	public State() {}
	public int getStateId() {
		return stateId;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public long getStatePopulation() {
		return statePopulation;
	}
	public void setStatePopulation(long statePopulation) {
		this.statePopulation = statePopulation;
	}
	
	public Country getCountry() {
		return country;
	}
	public void setCountry(Country country) {
		this.country = country;
	}
	@Override
	public String toString() {
		return "State [stateId=" + stateId + ", stateName=" + stateName
				+ ", statePopulation=" + statePopulation + "]";
	}
	
	
}
