



import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.capgemini.entity.Employee;
import com.capgemini.utility.SessionFactoryUtility;

public class TestORM {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	Employee employee=new Employee();//t
		//employee.setEmpName("vardhani");
		//employee.setEmpSalary(95000);
		
		SessionFactory sf=SessionFactoryUtility.createSessionFactory();
		//SessionFactory sf=config.buildSessionFactory();
		Session mySession=sf.openSession();
		Query query1=mySession.createQuery("from Employee e order by e.empId DESC");
		List<Employee> allRecords=query1.list();
		System.out.println("QUERY 1 RESULT");
		for(Employee e:allRecords)
		{
			System.out.println(e);
		}
		Query query2=mySession.createQuery("select e.empId,e.empSalary from Employee e");
		Iterator it=query2.iterate();
		System.out.println("QUERY 2 RESULT");
		while(it.hasNext())
		{
			Object row[]=(Object[])it.next();
			System.out.println(row[0]+"\t"+row[1]);
		}
		
		//QUERY 3
		Query query3=mySession.createQuery("update Employee set empName=:myName where empId=:employeeId");
		query3.setParameter("myName", "Tejaswi");
		query3.setParameter("employeeId", 30);
		
		int rowCount=query3.executeUpdate();
		System.out.println("no.of rows updates are "+rowCount );
		
		//QUERY 4
		
		Query query4=mySession.createQuery("select max(empSalary) from Employee");
		System.out.println("Max salary is"+query4.list().get(0));
		
		//QUERY 5
		
		Query query5=mySession.createQuery("select avg(empSalary) from Employee");
		System.out.println("Avg salary is"+query5.list().get(0));
		
		//QUERY 6
		
		Criteria criteria=mySession.createCriteria(Employee.class);
		criteria.add(Restrictions.ilike("empName", "%a%i"));
		List<Employee> allRec=criteria.list();
		for(Employee e1:allRec)
		{
			System.out.println(e1);
		}
		//QUERY 7
		
				Criteria criteria1=mySession.createCriteria(Employee.class);
				criteria1.add(Restrictions.gt("empSalary", new Float(60000)));
				List<Employee> allRec1=criteria1.list();
				for(Employee e2:allRec1)
				{
					System.out.println(e2);
				}
		//Session mySession1=sf.openSession();
		//Transaction tsx=mySession.beginTransaction();)
		
		//Integer emp=(Integer)mySession.save(employee);//p
		
		/*System.out.println("record is saved in database"+emp);
		Employee emp1=(Employee)mySession.get(Employee.class, 40);
		emp1.setEmpName("abc");
		
		mySession.clear();
		emp1.setEmpSalary(70000);
		mySession.saveOrUpdate(emp1);*/
		/*Employee employee1=(Employee)mySession.get(Employee.class, 2);
		Employee employee2=(Employee)mySession1.get(Employee.class, 2);*/
		/*employee.setEmpSalary(employee.getEmpSalary()+10000);
		
		mySession.update(employee);
		System.out.println("Record is updated");*/
		
		/*if(employee!=null)
		{
			mySession.delete(employee);
			System.out.println("record is deleted");
		}
		else
		{
			System.out.println("sorry record is not found");
		}*/
		//System.out.println(employee1);
		//System.out.println(employee2);
		
		
		//tsx.commit();
		SessionFactoryUtility.releaseSessionFactory();
	}

}
