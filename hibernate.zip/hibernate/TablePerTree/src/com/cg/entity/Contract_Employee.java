package com.cg.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value="contract_employee")
public class Contract_Employee extends Employee
{
	private int perday_wages;

	public int getPerday_wages() {
		return perday_wages;
	}

	public void setPerday_wages(int perday_wages) {
		this.perday_wages = perday_wages;
	}

	public Contract_Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
