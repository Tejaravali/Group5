package com.cg.ui;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.capgemini.utility.SessionFactoryUtility;
import com.cg.entity.Contract_Employee;
import com.cg.entity.Employee;
import com.cg.entity.Permanent_Employee;


public class TestTablePerTree {

	public static void main(String[] args) {
		
		
		SessionFactory sf=SessionFactoryUtility.createSessionFactory();
		
		Session mySession=sf.openSession();
		Transaction txn=mySession.beginTransaction();
		
		Employee employee=new Employee();
		employee.setName("Vardhani");
		
		Contract_Employee ce=new Contract_Employee();
		ce.setName("Teja");
		ce.setPerday_wages(60000);
		
		Permanent_Employee pe=new Permanent_Employee();
		pe.setName("ooha");
		pe.setBonus(10000);
		
		mySession.save(employee);
		mySession.save(pe);
		mySession.save(ce);
		
		System.out.println("Data is saved");
				
		txn.commit();
		
		SessionFactoryUtility.releaseSessionFactory();
	}

}
