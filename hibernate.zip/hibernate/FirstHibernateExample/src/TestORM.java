

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.capgemini.entity.Employee;
import com.capgemini.utility.SessionFactoryUtility;

public class TestORM {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Employee employee=new Employee();
		employee.setEmpName("Raj");
		employee.setEmpSalary(55000);*/
		
		SessionFactory sf=SessionFactoryUtility.createSessionFactory();
		//SessionFactory sf=config.buildSessionFactory();
		Session mySession=sf.openSession();
		Session mySession1=sf.openSession();
		Transaction tsx=mySession.beginTransaction();
		
		//mySession.save(employee);
		
		
		Employee employee1=(Employee)mySession.get(Employee.class, 2);
		Employee employee2=(Employee)mySession1.get(Employee.class, 2);
		/*employee.setEmpSalary(employee.getEmpSalary()+10000);
		
		mySession.update(employee);
		System.out.println("Record is updated");*/
		
		/*if(employee!=null)
		{
			mySession.delete(employee);
			System.out.println("record is deleted");
		}
		else
		{
			System.out.println("sorry record is not found");
		}*/
		System.out.println(employee1);
		System.out.println(employee2);
		
		SessionFactoryUtility.releaseSessionFactory();
		tsx.commit();

	}

}
