package com.capgemini.utility;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SessionFactoryUtility {

	static SessionFactory sf;
	public static SessionFactory createSessionFactory() {
		Configuration config=new Configuration().configure();
		sf=config.buildSessionFactory();
		return sf;
		// TODO Auto-generated method stub

	}
	
	public static void releaseSessionFactory(){
		sf.close();
	}

}
